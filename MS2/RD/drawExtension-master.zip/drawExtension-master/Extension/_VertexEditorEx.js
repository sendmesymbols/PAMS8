
define("dojo/_base/declare dojo/_base/lang dojo/_base/connect dojo/_base/array dojo/has dijit/Menu dijit/MenuItem esri/kernel Extension/_VertexMoverEx esri/geometry/Point esri/geometry/jsonUtils dojo/i18n!esri/nls/jsapi".split(" "), function (declare, lang, connect, Array, has, Menu, MenuItem, esriKernel, _VertexMover, Point, jsonUtils, nls)
{
	var VertexEditor = declare(null, {declaredClass: "esri.toolbars._GraphicVertexEditorEx",
		constructor: function (graphic, map, toolbar)
		{
			this.graphic = graphic;
			this.map = map;
			this.toolbar = toolbar;
			var toolbarOptions = toolbar._options;
			this._symbol1 = toolbarOptions.vertexSymbol;
			this._symbol2 = toolbarOptions.ghostVertexSymbol;
			var ghostLineSymbol = toolbarOptions.ghostLineSymbol;
			this._lineStroke = {style: ghostLineSymbol.style, width: ghostLineSymbol.width, color: ghostLineSymbol.color};
			this._canDel = toolbarOptions.allowDeleteVertices;
			this._canAdd = toolbarOptions.allowAddVertices;
			this._addControllers()
		},
		destroy: function ()
		{
			this._removeControllers()
		},
		refresh: function (a)
		{
			a ? (this._removeControllers(), this._addControllers()) : (this._refresh(this._vertexMovers), this._refresh(this._mpVertexMovers))
		},
		suspend: function ()
		{
			this._suspended || this._removeControllers();
			this._suspended = !0
		},
		resume: function ()
		{
			this._suspended && this._addControllers();
			this._suspended = !1
		},
		_addControllers: function ()
		{
			this._firstMoveHandle = connect.connect(_VertexMover, "onFirstMove", this, this._firstMoveHandler);
			this._moveStopHandle = connect.connect(_VertexMover, "onMoveStop", this, this._moveStopHandler);
			this._vertexMovers = this._add(this._getSegments(this.graphic.geometry), this._symbol1);
			//middle point vertex mover
			this._canAdd && (this._mpVertexMovers = this._add(this._getMidpointSegments(this.graphic.geometry), this._symbol2, !0));
			var graphicLayer = this._getGraphicsLayer();
			this._mouseOverHandle = connect.connect(graphicLayer, "onMouseOver", this, this._mouseOverHandler);
			this._mouseOutHandle = connect.connect(graphicLayer, "onMouseOut", this, this._mouseOutHandler);
			this._canDel && (this._ctxMenu = new Menu({style: "font-size: 12px; margin-left: 5px; margin-top: 5px;"}), graphicLayer = this._ctxDelete = new MenuItem({label: nls.toolbars.edit.deleteLabel, iconClass: "vertexDeleteIcon", style: "outline: none;"}), this._deleteHandle = connect.connect(graphicLayer, "onClick", this, this._deleteHandler), this._ctxMenu.addChild(graphicLayer), this._ctxMenu.startup())
		},
		_removeControllers: function ()
		{
			connect.disconnect(this._firstMoveHandle);
			connect.disconnect(this._moveStopHandle);
			connect.disconnect(this._mouseOverHandle);
			connect.disconnect(this._mouseOutHandle);
			connect.disconnect(this._deleteHandle);
			this._ctxMenu && (this._ctxDelete = null, this._unbindCtxNode(), this._ctxMenu.destroyRecursive());
			this._remove(this._vertexMovers);
			this._remove(this._mpVertexMovers);
			this._vertexMovers = this._mpVertexMovers = null
		},
		_add: function (pointCollection, symbol, isPlaceHolder)
		{
			var segIndex, ptIndex, graphic = this.graphic, g = [];
			for (segIndex = 0; segIndex < pointCollection.length; segIndex++)
			{
				var h = pointCollection[segIndex], k = [];
				for (ptIndex = 0; ptIndex < h.length; ptIndex++)
					k.push(new _VertexMover(h[ptIndex], symbol, graphic, segIndex, ptIndex, h.length, this, isPlaceHolder));
				g.push(k)
			}
			return g
		},
		_remove: function (a)
		{
			a &&
			Array.forEach(a, function (a)
			{
				Array.forEach(a, function (a)
				{
					a.destroy()
				})
			})
		},
		_refresh: function (a)
		{
			a && Array.forEach(a, function (a)
			{
				Array.forEach(a, function (a)
				{
					a.refresh()
				})
			})
		},
		_isNew: function (a)
		{
			return-1 === Array.indexOf(this._vertexMovers[a.segIndex], a) ? !0 : !1
		},
		_getGraphicsLayer: function ()
		{
			return this.toolbar._scratchGL
		},
		_deleteHandler: function (a)
		{
			a = this._selectedMover;
			this._updateRelatedGraphic(a, a.relatedGraphic, a.graphic.geometry, a.segIndex, a.ptIndex, a.segLength, !1, !0);
			this._canAdd && this._deleteMidpoints(a);
			a.relatedGraphic.getDojoShape().moveToBack();
			this._deleteVertex(a);
			this.toolbar._endOperation("VERTICES")
		},
		_mouseOverHandler: function (a)
		{
			a = a.graphic;
			var b = this._findMover(a);
			b && (this.toolbar.onVertexMouseOver(this.graphic, b._getInfo()), b._placeholder || (this._selectedMover = b, this._canDel && this._bindCtxNode(a.getDojoShape().getNode())))
		},
		_mouseOutHandler: function (a)
		{
			if (a = this._findMover(a.graphic))this.toolbar.onVertexMouseOut(this.graphic, a._getInfo())
		},
		_bindCtxNode: function (a)
		{
			this._unbindCtxNode();
			this._ctxDelete.set("disabled", this._selectedMover.segLength <= this.minLength ? !0 : !1);
			this._ctxMenu.bindDomNode(a);
			this._bindNode = a
		},
		_unbindCtxNode: function ()
		{
			var a = this._bindNode;
			a && this._ctxMenu.unBindDomNode(a)
		},
		_findMover: function (a)
		{
			var b, c = [];
			b = this._mpVertexMovers;
			Array.forEach(this._vertexMovers, function (a)
			{
				c = c.concat(a)
			});
			b && Array.forEach(b, function (a)
			{
				c = c.concat(a)
			});
			for (b = 0; b < c.length; b++)
			{
				var e = c[b];
				if (e.graphic === a)return e
			}
		},
		_firstMoveHandler: function (a)
		{
			!this._isNew(a) && this._canAdd && this._hideRelatedMidpoints(a);
			this.toolbar._beginOperation("VERTICES")
		},
		_moveStopHandler: function (a, b)
		{
			var c = this._isNew(a);
			!b || !b.dx && !b.dy ? !c && this._canAdd && this._showRelatedMidpoints(a) : (this._updateRelatedGraphic(a, a.relatedGraphic, a.graphic.geometry, a.segIndex, a.ptIndex, a.segLength, c), this._canAdd && (c ? this._addMidpoints(a) : (this._repositionRelatedMidpoints(a), this._showRelatedMidpoints(a))), this.toolbar._endOperation("VERTICES"))
		},
		_showRelatedMidpoints: function (a)
		{
			var b = this._getAdjacentMidpoints(a.ptIndex, a.segLength), c = this._mpVertexMovers[a.segIndex];
			for (a = 0; a < b.length; a++)
			{
				var e = c[b[a]];
				e.graphic.show();
				e.refresh()
			}
		},
		_hideRelatedMidpoints: function (a)
		{
			var b = this._getAdjacentMidpoints(a.ptIndex, a.segLength), c = this._mpVertexMovers[a.segIndex];
			for (a = 0; a < b.length; a++)
				c[b[a]].graphic.hide();
		},
		_repositionRelatedMidpoints: function (a)
		{
			var b, c = this._getAdjacentMidpoints(a.ptIndex, a.segLength), e = this._mpVertexMovers[a.segIndex];
			for (b = 0; b < c.length; b++)
			{
				var d = this._getAdjacentVertices(c[b], a.segLength), f = a.relatedGraphic.geometry.getPoint(a.segIndex, d[0]), d = a.relatedGraphic.geometry.getPoint(a.segIndex,
				                                                                                                                                                       d[1]), f = new Point({x: (f.x + d.x) / 2, y: (f.y + d.y) / 2, spatialReference: f.spatialReference.toJson()});
				e[c[b]].graphic.setGeometry(f)
			}
		},
		_addMidpoints: function (a)
		{
			var b = a.segIndex, c = a.ptIndex, e = a.segLength, d = c + 1, f, g = e + 1;
			this._mpVertexMovers[b].splice(c, 1);
			var h = this._vertexMovers[b];
			for (f = 0; f < d; f++)h[f].segLength += 1;
			for (f = d; f < h.length; f++)h[f].ptIndex += 1, h[f].segLength += 1;
			a.ptIndex = d;
			a.segLength = h.length + 1;
			h.splice(d, 0, a);
			a.graphic.setSymbol(this._symbol1);
			h = this._mpVertexMovers[b];
			for (f = 0; f < c; f++)h[f].segLength +=
				1;
			for (f = c; f < e - 1; f++)h[f].ptIndex += 1, h[f].segLength += 1;
			d = this._getAdjacentVertices(c, g);
			b = this._getAdjacentVertices(c + 1, g);
			e = a.relatedGraphic.geometry.getPoint(a.segIndex, d[0]);
			f = a.relatedGraphic.geometry.getPoint(a.segIndex, d[1]);
			d = new Point({x: (e.x + f.x) / 2, y: (e.y + f.y) / 2, spatialReference: e.spatialReference.toJson()});
			e = a.relatedGraphic.geometry.getPoint(a.segIndex, b[0]);
			f = a.relatedGraphic.geometry.getPoint(a.segIndex, b[1]);
			b = new Point({x: (e.x + f.x) / 2, y: (e.y + f.y) / 2, spatialReference: e.spatialReference.toJson()});
			e = new _VertexMover(d, this._symbol2, this.graphic, a.segIndex, c, g, this, !0);
			a = new _VertexMover(b, this._symbol2, this.graphic, a.segIndex, c + 1, g, this, !0);
			h.splice(c, 0, e, a)
		},
		_deleteVertex: function (a)
		{
			var b, c = a.ptIndex, e = this._vertexMovers[a.segIndex];
			for (b = 0; b < c; b++)e[b].segLength -= 1;
			for (b = c + 1; b < e.length; b++)
			{
				var d = e[b];
				d.ptIndex -= 1;
				d.segLength -= 1
			}
			e.splice(c, 1);
			b = a._getInfo();
			a.destroy();
			this.toolbar.onVertexDelete(this.graphic, b)
		}});
	lang.mixin(VertexEditor, {create: function (a, b, c)
	{
		switch (a.geometry.type)
		{
			case "multipoint":
				return new VertexEditor.MultipointVertexEditor(a, b, c);
			case "polyline":
				return new VertexEditor.PolylineVertexEditor(a, b, c);
			case "polygon":
				return new VertexEditor.PolygonVertexEditor(a, b, c);
		}
	}});
	VertexEditor.MultipointVertexEditor = declare(VertexEditor, {declaredClass: "esri.toolbars._MultipointVertexEditor",
		minLength: 1,
		constructor: function ()
		{
			this._moveStartHandle = connect.connect(_VertexMover, "onMoveStart", this, this._moveStartHandler);
			connect.disconnect(this._firstMoveHandle)
		},
		destroy: function ()
		{
			this.inherited(arguments);
			connect.disconnect(this._moveStartHandle)
		},
		_getSegments: function (geometry)
		{
			var pointCollection = geometry.points, result = [], spatialReference = geometry.spatialReference;
			for (var i = 0; i < pointCollection.length; i++)
			{
				var d = pointCollection[i];
				result.push(new Point({x: d[0], y: d[1], spatialReference: spatialReference.toJson()}))
			}
			return[result];
		},
		_getMidpointSegments: function (a)
		{
			return[]
		},
		_getControlPoints: function (a, b, c, e, d)
		{
			return[]
		},
		_getGraphicsLayer: function ()
		{
			return this.graphic._graphicsLayer
		},
		_mouseOverHandler: function (a)
		{
			var b = a.graphic;
			if (a = this._findMover(a))this.toolbar.onVertexMouseOver(b, a._getInfo()), this._selectedMover = a, this._canDel && this._bindCtxNode(a.graphic.getDojoShape().getNode())
		},
		_mouseOutHandler: function (a)
		{
			var b =
				a.graphic;
			if (a = this._findMover(a))this.toolbar.onVertexMouseOut(b, a._getInfo())
		},
		_findMover: function (a)
		{
			var b = [].concat(this._vertexMovers[0]), c = a.target;
			for (a = 0; a < b.length; a++)
			{
				var e = b[a];
				if (e.graphic.getDojoShape().getNode() === c)return e
			}
		},
		_moveStartHandler: function (a)
		{
			var b = a.ptIndex, c = a.segLength - 1, e = a.relatedGraphic.geometry.points;
			a = e.splice(b, 1);
			e.push(a[0]);
			e = this._vertexMovers[0];
			for (a = c; a > b; a--)e[a].ptIndex -= 1;
			a = e.splice(b, 1);
			e.push(a[0]);
			a[0].ptIndex = c
		},
		_moveStopHandler: function (a)
		{
			this._updateRelatedGraphic(a,
			                           a.relatedGraphic, a.graphic.geometry, a.segIndex, a.ptIndex, a.segLength);
			this.toolbar._endOperation("VERTICES")
		},
		_updateRelatedGraphic: function (a, b, c, e, d, f, g, h)
		{
			a = b.geometry;
			h ? a.removePoint(d) : a.setPoint(d, c);
			b.setGeometry(a)
		},
		_deleteMidpoints: function (a)
		{
		}});
	VertexEditor.PolylineVertexEditor = declare(VertexEditor, {declaredClass: "esri.toolbars._PolylineVertexEditor",
		minLength: 2,
		_getSegments: function (geometry)
		{
			var i, j, paths = geometry.paths, result = [];
			for (i = 0; i < paths.length; i++)
			{
				var path = paths[i], g = [];
				for (j = 0; j < path.length; j++)
					g.push(geometry.getPoint(i, j));
				result.push(g)
			}
			return result
		},
		_getMidpointSegments: function (a)
		{
			var b, c, e = a.paths, d = [], f = a.spatialReference;
			for (b = 0; b < e.length; b++)
			{
				var g = e[b], h = [];
				for (c = 0; c < g.length - 1; c++)
				{
					var k = a.getPoint(b, c), l = a.getPoint(b, c + 1), k = new Point({x: (k.x + l.x) / 2, y: (k.y + l.y) / 2, spatialReference: f.toJson()});
					h.push(k)
				}
				d.push(h)
			}
			return d
		},
		_getControlPoints: function (a, b, c, e, d)
		{
			var f = this.map, g, h;
			this._isNew(a) ? (a = e, e += 1, 0 <= a && (g = f.toScreen(b.getPoint(c, a))), e <= d && (h = f.toScreen(b.getPoint(c, e)))) : (a = e - 1, e += 1, 0 <= a && (g = f.toScreen(b.getPoint(c, a))), e < d && (h = f.toScreen(b.getPoint(c,
			                                                                                                                                                                                                                                     e))));
			return[g, h]
		},
		_getAdjacentMidpoints: function (ptIndex, segLength)
		{
			var c = [], e = ptIndex - 1;
			0 <= e && c.push(e);
			ptIndex < segLength - 1 && c.push(ptIndex);
			return c
		},
		_getAdjacentVertices: function (a, b)
		{
			return[a, a + 1]
		},
		_deleteMidpoints: function (a)
		{
			var b = this._mpVertexMovers[a.segIndex], c = b.length - 1, e = this._getAdjacentMidpoints(a.ptIndex, a.segLength).sort(), d, f = e[0];
			for (d = 0; d < f; d++)b[d].segLength -= 1;
			for (d = f + 1; d < b.length; d++)
			{
				var g = b[d];
				g.ptIndex -= 1;
				g.segLength -= 1
			}
			if (1 === e.length)b.splice(f, 1)[0].destroy(); else
			{
				g = this._getAdjacentVertices(f, c);
				d = a.relatedGraphic.geometry.getPoint(a.segIndex,
				                                       g[0]);
				g = a.relatedGraphic.geometry.getPoint(a.segIndex, g[1]);
				d = new Point({x: (d.x + g.x) / 2, y: (d.y + g.y) / 2, spatialReference: d.spatialReference.toJson()});
				a = new _VertexMover(d, this._symbol2, this.graphic, a.segIndex, f, c, this, !0);
				b = b.splice(f, e.length, a);
				for (d = 0; d < b.length; d++)b[d].destroy()
			}
		},
		_updateRelatedGraphic: function (a, b, c, e, d, f, g, h)
		{
			a = b.geometry;
			g ? a.insertPoint(e, d + 1, jsonUtils.fromJson(c.toJson())) : h ? a.removePoint(e, d) : a.setPoint(e, d, jsonUtils.fromJson(c.toJson()));
			b.setGeometry(a)
		}});
	VertexEditor.PolygonVertexEditor = declare(VertexEditor, {declaredClass: "esri.toolbars._PolygonVertexEditor",
		minLength: 3,
		_getSegments: function (a)
		{
			var b, c, e = a.rings, d = [];
			for (b = 0; b < e.length; b++)
			{
				var f = e[b], g = [];
				for (c = 0; c < f.length - 1; c++)g.push(a.getPoint(b, c));
				d.push(g)
			}
			return d
		},
		_getMidpointSegments: function (a)
		{
			var b, c, e = a.rings, d = [], f = a.spatialReference;
			for (b = 0; b < e.length; b++)
			{
				var g = e[b], h = [];
				for (c = 0; c < g.length - 1; c++)
				{
					var k = a.getPoint(b, c), l = a.getPoint(b, c + 1), k = new Point({x: (k.x + l.x) / 2, y: (k.y + l.y) / 2, spatialReference: f.toJson()});
					h.push(k)
				}
				d.push(h)
			}
			return d
		},
		_getControlPoints: function (a, b, c, e, d)
		{
			var f = this.map;
			this._isNew(a) ? a = e : (a = e - 1, a = 0 > a ? (d + a) % d : a);
			e = (e + 1) % d;
			d = f.toScreen(b.getPoint(c, a));
			b = f.toScreen(b.getPoint(c, e));
			return[d, b]
		},
		_getAdjacentMidpoints: function (a, b)
		{
			var c = a - 1;
			return[0 > c ? (b + c) % b : c, a]
		},
		_getAdjacentVertices: function (a, b)
		{
			return[a, (a + 1) % b]
		},
		_deleteMidpoints: function (a)
		{
			var b = a.ptIndex, c = this._mpVertexMovers[a.segIndex], e = c.length - 1, d = this._getAdjacentMidpoints(b, a.segLength).sort(), f, g;
			g = d[0];
			var h = d[d.length - 1];
			if (0 === b)
			{
				f = this._getAdjacentVertices(e - 1, e);
				b = a.relatedGraphic.geometry.getPoint(a.segIndex,
				                                       f[0]);
				f = a.relatedGraphic.geometry.getPoint(a.segIndex, f[1]);
				b = new Point({x: (b.x + f.x) / 2, y: (b.y + f.y) / 2, spatialReference: b.spatialReference.toJson()});
				a = new _VertexMover(b, this._symbol2, this.graphic, a.segIndex, e - 1, e, this, !0);
				c.splice(h, 1, a)[0].destroy();
				c.splice(g, 1)[0].destroy();
				for (d = 0; d < c.length - 1; d++)g = c[d], g.ptIndex -= 1, g.segLength -= 1
			} else
			{
				f = this._getAdjacentVertices(g, e);
				b = a.relatedGraphic.geometry.getPoint(a.segIndex, f[0]);
				f = a.relatedGraphic.geometry.getPoint(a.segIndex, f[1]);
				b = new Point({x: (b.x + f.x) / 2, y: (b.y + f.y) /
					2, spatialReference: b.spatialReference.toJson()});
				a = new _VertexMover(b, this._symbol2, this.graphic, a.segIndex, g, e, this, !0);
				h = c.splice(g, d.length, a);
				for (d = 0; d < h.length; d++)h[d].destroy();
				for (d = 0; d < g; d++)c[d].segLength -= 1;
				for (d = g + 1; d < c.length; d++)g = c[d], g.ptIndex -= 1, g.segLength -= 1
			}
		},
		_updateRelatedGraphic: function (a, b, c, e, d, f, g, h)
		{
			a = b.geometry;
			g ? a.insertPoint(e, d + 1, jsonUtils.fromJson(c.toJson())) : h ? (a.removePoint(e, d), 0 === d && a.setPoint(e, f - 1, jsonUtils.fromJson(a.getPoint(e, 0).toJson()))) : (a.setPoint(e, d, jsonUtils.fromJson(c.toJson())),
				0 === d && a.setPoint(e, f, jsonUtils.fromJson(c.toJson())));
			b.setGeometry(a)
		}});
	has("extend-esri") && (lang.setObject("toolbars._GraphicVertexEditorEx", VertexEditor, esriKernel), lang.setObject("toolbars._MultipointVertexEditor", VertexEditor.MultipointVertexEditor, esriKernel), lang.setObject("toolbars._PolylineVertexEditor", VertexEditor.PolylineVertexEditor, esriKernel), lang.setObject("toolbars._PolygonVertexEditor", VertexEditor.PolygonVertexEditor, esriKernel));
	return VertexEditor;
});