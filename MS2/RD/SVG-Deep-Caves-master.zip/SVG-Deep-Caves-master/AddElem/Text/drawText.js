function shadowDrawTextChecked()
{

    var cw = addElemTextCw
  if(ActiveElem)
  {
    if(cw.shadowDrawTextCheck.checked )
        ActiveElem.attr('filter', "url(#drop-shadow)")
    else
      activeElem.removeAttribute('filter')
  }
}

//---during drag of element add class 'noselect' to text elements---
//---start Drag---
function addNoSelectAtText()
{
    for(var k = 0; k<domElemG.childNodes.length; k++)
    {

        var elem = domElemG.childNodes.item(k)

        if(elem.nodeName=="text")
            elem.setAttribute("class", "noselect")

    }

}
//---end drag---
function removeNoSelectAtText()
{
    for(var k = 0; k<domElemG.childNodes.length; k++)
    {

        var elem = domElemG.childNodes.item(k)
        if(elem.nodeName=="text")
            elem.setAttribute("class", "textElem")

    }

}

//---on add icon DrawX follows cursor
function trackDrawText()
{

    if(ActiveElem==null&&DrawTextStarted==true)
    {

        DrawX.style("display", "inline")
        DrawX.attr("transform", "translate("+SVGx+" "+SVGy+")")

    }
}

var TextBlinker;
var TextBlinkerInterval;
var BlinkerLoc;
function startBlinker()
{
    TextBlinkerInterval = setInterval("blinkIt()", 500);
}
function blinkIt()
{
    var blinkVis = TextBlinker.style("visibility")
    if(blinkVis=="visible")
        TextBlinker.style("visibility", "hidden")
        else
            TextBlinker.style("visibility", "visible")
}

var NextLine = false
var TspanCnt = 0
//----enter key---
function nextTextLine()
{
    TspanCnt++;
    var prevLineLength = activeTspan.getComputedTextLength()

    ActiveTspan.attr("id", null)
    var NS = "http://www.w3.org/2000/svg"
    var span2 = document.createElementNS(NS, "tspan");
    //var dy=TspanCnt+"em"
    span2.setAttribute("dy", "1em");
    span2.setAttribute("id", "activeTspan")

    span2.setAttribute("dx", -prevLineLength);

    TextBlinker.style("visibility", "visible")

    NextLine = false

    TextBlinker.attr("dx", -prevLineLength);
    var dy = "1em"
    TextBlinker.attr("dy", dy);
    activeText.insertBefore(span2, textBlinker);

    ActiveTspan = d3.select("#activeTspan")
    activeTspan = document.getElementById("activeTspan")
    WriteText = "";

    NextLine = true

    return false
}
//---back button removes all characters of last tspan---
function removeLastTspan()
{

    TspanCnt--;
    var tspans = activeText.childNodes
    var tspanCnt = tspans.length
    var lastTspan = tspans.item(tspanCnt-2) //---last tspan before blinker---
    var currentTspan = tspans.item(tspanCnt-3)
    activeText.removeChild(lastTspan)
    currentTspan.setAttribute("id", "activeTspan")

    ActiveTspan = d3.select("#activeTspan")
    activeTspan = document.getElementById("activeTspan")
    WriteText = activeTspan.textContent;
    addElemTextCw.drawTextWriteTextValue.value = WriteText

}

//----on Enter Key for multiple line text---!
var TspanCnt = 0;
var TSpanON = false;
var WriteText = "";
//---plant Tspan Blinker;;;
var ActiveTspan
var activeTspan

var DrawText = false
var DrawTextEdit = false
var TextCenter =[]
var RotateAngle

var DrawTextStarted = false
function startTextDraw()
{
    activeElem = null
    ActiveElem = null
    
    mySVG.setAttribute('onclick', "placeDrawText()")
    RotateAngle = 0
    TspanCnt = 0;
    TSpanON = true;
    InsertSpanON = false
    WriteText = "";
      MyMap.scrollWheelZoom.disable();
       MyMap.dragging.disable()
    DrawTextStarted = true
    DrawX.attr("stroke", "violet")
           mySVG.setAttribute("cursor","default")
        MyMap.scrollWheelZoom.disable();
        MyMap.dragging.disable()

}
var textFillColor = "black"
function setTextColor()
{
    var cw = addElemTextCw

    textFillColor = cw.drawTextFillSelect.options[cw.drawTextFillSelect.selectedIndex].value
    if(ActiveElem)
    {
        ActiveElem.attr('fill', textFillColor)
        TextBlinker.attr('fill', textFillColor)
    }
}
function drawTextFontFamilySelected()
{

    var cw = addElemTextCw

    var fontFamily = cw.drawTextFontFamilySelect.options[cw.drawTextFontFamilySelect.selectedIndex].value

    cw.fontFamilySpan.style.fontFamily = fontFamily
    if(ActiveElem)
    {
        ActiveElem.attr('font-family', fontFamily)

    }
}
var FontWeight = "normal"
function drawTextBoldChecked()
{
    var cw = addElemTextCw

    if(cw.drawTextBoldCheck.checked)
    {
        FontWeight = "bold"
        if(ActiveElem)
            ActiveElem.attr('font-weight', "bold")
    }
    else
    {
        FontWeight = "normal"
        if(ActiveElem)
            ActiveElem.attr('font-weight', "normal")
    }
    if(ActiveElem)
        textReset()
        cw.fontFamilySpan.style.fontWeight = FontWeight
}
var FontStyle = "normal"
function drawTextItalicChecked()
{
    var cw = addElemTextCw

    if(cw.drawTextItalicCheck.checked)
    {
        FontStyle = "italic"
        if(ActiveElem)
            ActiveElem.attr('font-style', "italic")

    }
    else
    {
        FontStyle = "normal"
        if(ActiveElem)
            ActiveElem.attr('font-style', "normal")
    }

    cw.fontFamilySpan.style.fontStyle = FontStyle
    if(ActiveElem)
        textReset()
}

//---click on svg layer---
var TextElem //--g child node---
function placeDrawText()
{
         MyMap.scrollWheelZoom.disable();
       MyMap.dragging.disable()

    var cw = addElemTextCw

    mySVG.removeAttribute("onclick")
    cw.drawTextWriteTextValue.value = ""
    cw.shadowDrawTextCheck.checked=false
    cw.drawTextWriteTextValue.addEventListener("keypress", cw.drawTextKeyPress, false)
    cw.drawTextWriteTextValue.addEventListener("keyup", cw.drawTextKeyUp, false)

    var fontSize = parseInt(cw.drawTextFontSizeSelect.options[cw.drawTextFontSizeSelect.selectedIndex].text, 10)
    var fontFamily = cw.drawTextFontFamilySelect.options[cw.drawTextFontFamilySelect.selectedIndex].value
    var textStrokeColor=cw.drawTextStrokeSelect.options[cw.drawTextStrokeSelect.selectedIndex].value
   if(ActiveElem)
      ActiveElem.attr('stroke', textStrokeColor)
   if(ActiveElem && textStrokeColor!="none")
   {         var strokeWidth = .02*fontSize
            ActiveElem.attr('strokeWidth', strokeWidth)

   }
    textFillColor = cw.drawTextFillSelect.options[cw.drawTextFillSelect.selectedIndex].value
    if(cw.drawTextBoldCheck.checked)
    {
        FontWeight = "bold"
        if(ActiveElem)
            ActiveElem.attr('font-weight', "bold")
    }
    else
    {
        FontWeight = "normal"
        if(ActiveElem)
            ActiveElem.attr('font-weight', "normal")
    }

    if(cw.drawTextItalicCheck.checked)
    {
        FontStyle = "italic"
        if(ActiveElem)
            ActiveElem.attr('font-style', "italic")

    }
    else
    {
        FontStyle = "normal"
        if(ActiveElem)
            ActiveElem.attr('font-style', "normal")
    }
   var textStrokeColor=cw.drawTextStrokeSelect.options[cw.drawTextStrokeSelect.selectedIndex].value

   if(textStrokeColor!="none")
    var strokeWidth = .02*fontSize
  else
    var strokeWidth=0

    ActiveElem = ActiveElemG.append("g")
    .attr("id", "activeElem")
    .attr("fill", textFillColor)
    .attr("stroke", textStrokeColor)
   .attr("stroke-width", strokeWidth)
    .attr("font-size", fontSize)
    .attr("font-family", fontFamily)
    .attr("font-weight", FontWeight)
    .attr("font-style", FontStyle)
    .attr("transform", "translate(0 0)")
    .attr("class", "dragTargetObj")
     .attr("InitZoom", MapZoom)

    activeElem = document.getElementById("activeElem")

    TextElem = ActiveElem.append("svg:text")
    .attr("id", "activeText")
    .attr("x", 0)
    .attr("y", 0)

    ActiveTspan = TextElem.append("tspan")
    .attr("id", "activeTspan")
    activeTspan = document.getElementById("activeTspan")
    //---blinker---!
    var blink = "|";

    TextBlinker = TextElem.append("tspan")
    .text(blink)
    .style("visibility", "visible")
    .attr("id", "textBlinker")
    .attr("dx", "4")
    .attr("stroke", "none")
    .attr("fill", textFillColor)
    .attr("fill-opacity", 1)
    .attr("font-weight", "normal")
    .attr("font-style", "normal")
    .attr("font-family", "Arial")
    .attr("font-size", fontSize)

    startBlinker()
    mySVG.setAttribute("onmousedown", "startDragText(evt)")
    mySVG.setAttribute("onmousemove", "dragText(evt)")
    mySVG.setAttribute("onmouseup", "endDragText(evt);addElemTextCw.focusText()")

    coverOn()

    TextCenter =[SVGx, SVGy]

    var transformRequestObj = mySVG.createSVGTransform()
    var animTransformList = activeElem.transform
    var transformList = animTransformList.baseVal
    transformRequestObj.setTranslate(SVGx, SVGy)
    transformList.appendItem(transformRequestObj)
    transformList.consolidate()

    DrawX.style("display", "inline")
    DrawX.attr("transform", ActiveElem.attr("transform"))

   // cw.shadowDrawTextButton.disabled = false
    cw.finishDrawTextButton.disabled = false
    cw.cancelDrawTextButton.disabled = false
            cw.drawTextBotButton.disabled=false

    DrawText = true
    cw.focusText()
    ///----when elem contained in <g>----

    setTimeout('ActiveElem.style("cursor","move")', 1200)
}
//---change size,family---
function textReset()
{
    var cw = addElemTextCw
    var fontSize = parseInt(cw.drawTextFontSizeSelect.options[cw.drawTextFontSizeSelect.selectedIndex].text, 10)
    // var strokeWidth = .01*fontSize
    var fontFamily = cw.drawTextFontFamilySelect.options[cw.drawTextFontFamilySelect.selectedIndex].text
    if(cw.drawTextBoldCheck.checked)
    {
        FontWeight = "bold"
        if(ActiveElem)
            ActiveElem.attr('font-weight', "bold")
    }
    else
    {
        FontWeight = "normal"
        if(ActiveElem)
            ActiveElem.attr('font-weight', "normal")
    }

    if(cw.drawTextItalicCheck.checked)
    {
        FontStyle = "italic"
        if(ActiveElem)
            ActiveElem.attr('font-style', "italic")

    }
    else
    {
        FontStyle = "normal"
        if(ActiveElem)
            ActiveElem.attr('font-style', "normal")
    }

    TextBlinker.attr("font-size", fontSize)

 showDrawTextStrokeBg()
    ActiveElem.attr("font-weight", FontWeight)
    ActiveElem.attr("font-size", fontSize)
    ActiveElem.attr("font-style", FontStyle)
    ActiveElem.attr("font-family", fontFamily)
}

function drawTextFontSizeSelected()
{
    if(ActiveElem)
        textReset()

}

//==================CLOSE/CANCEL/FINISH========================
function closeDrawText()
{
    var cw = addElemTextCw
    if(ActiveElem&&activeElem)
    {
        domActiveElemG.removeChild(activeElem)
        var elemTimelinded = false

    }
    clearInterval(TextBlinkerInterval)
    ActiveElem = null

    activeElem = null
    NextLine = false
    TspanCnt = 0
    var cw = addElemTextCw
    RotateAngle = 0
    mySVG.removeAttribute("onclick")
    DrawX.style("display", "none")
    cw.finishDrawTextButton.disabled = true
    cw.cancelDrawTextButton.disabled = true
    cw.deleteDrawTextButton.style.visibility = "hidden"
        cw.drawTextTopButton.style.visibility = "hidden"
       // cw.drawEllipseBotButton.style.visibility = "hidden"
            cw.drawTextBotButton.disabled=true


    DrawText = false
      cw.shadowDrawTextCheck.checked=false
    cw.drawTextWriteTextValue.removeEventListener("keypress", cw.drawTextKeyPress)
    cw.drawTextWriteTextValue.removeEventListener("keyup", cw.drawTextKeyUp)

    DrawTextStarted = false
    mySVG.removeAttribute("onmousedown")

    mySVG.removeAttribute("onmouseup")
    WriteText = "";
    cw.drawTextWriteTextValue.value = ""
    cw.drawTextTopTable.style.backgroundColor = "linen"
    cw.botTextTable.style.backgroundColor = "linen"
    cw.containerDiv.style.backgroundColor = "linen"
    cw.editTextSpan.innerHTML = "Write"
    cw.textClickOnTD.style.visibility="visible"

    if(EditText==true&&TextDeleted==false)
    {
        var elemObjEdit = document.getElementById(DrawTextEditId)
        elemObjEdit.setAttribute("onmousedown", "editTextDraw("+DrawTextEditId+",evt)")

        elemObjEdit.style.visibility = ""
        elemObjEdit.style.cursor = "default"
        EditText = false
        closeIframe("addElemText");
    }
    DrawX.attr("stroke", "violet")
    coverOff()
    TextDeleted = false
    cw.adjustedRotateTextValue.value = "0"
    removeNoSelectAtText()
    MyMap.dragging.enable()
   MyMap.scrollWheelZoom.enable();
}
function cancelDrawText()
{
    var cw = addElemTextCw
    mySVG.setAttribute('onclick', "placeDrawText()")

    cw.finishDrawTextButton.disabled = true
    cw.cancelDrawTextButton.disabled = true
    cw.drawTextBotButton.disabled=true
    DrawText = false
    DrawX.attr("stroke", "violet")

    cw.drawTextWriteTextValue.removeEventListener("keypress", cw.drawTextKeyPress)
    cw.drawTextWriteTextValue.removeEventListener("keyup", cw.drawTextKeyUp)
    if(ActiveElem&&activeElem)
    {
        domActiveElemG.removeChild(activeElem)

    }
    WriteText = "";
    NextLine = false
    TspanCnt = 0
    clearInterval(TextBlinkerInterval)
    ActiveElem = null

    activeElem = null
    if(EditText==true)
    {
        closeDrawText()
        closeIframe("addElemText");

        var elemObjEdit = document.getElementById(DrawTextEditId)
        elemObjEdit.style.visibility = ""
        elemObjEdit.style.cursor = "default"

    }
    cw.adjustedRotateTextValue.value = "0"
    MyMap.dragging.enable()
    MyMap.scrollWheelZoom.enable();

}

function finishDrawText()
{
    if(WriteText!="")
    {
        if(EditText==true)
            finishEditText()
            else if(document.getElementById("activeElem"))
            {
                var cw = addElemTextCw
                activeElem.removeAttribute("class")
                    var id = "text"+new Date().getTime()
               var finishedElem = document.getElementById("activeElem").firstChild.cloneNode(true)
                finishedElem.setAttribute("id", id)
                finishedElem.setAttribute("font-family", ActiveElem.attr("font-family"))
                finishedElem.setAttribute("font-size", ActiveElem.attr("font-size"))
                finishedElem.setAttribute("font-weight", ActiveElem.attr("font-weight"))
                finishedElem.setAttribute("font-style", ActiveElem.attr("font-style"))
                finishedElem.setAttribute("stroke", ActiveElem.attr("stroke"))
                finishedElem.setAttribute("stroke-width", ActiveElem.attr("stroke-width"))
                finishedElem.setAttribute("fill", ActiveElem.attr("fill"))
                finishedElem.setAttribute("transform", ActiveElem.attr("transform"))
                finishedElem.setAttribute("filter", ActiveElem.attr("filter"))

                finishedElem.setAttribute("onmousedown", "editTextDraw("+id+",evt)")

                finishedElem.setAttribute("style","cursor:default")

                finishedElem.textContent=WriteText

                //---is this text rotated?---
                var ctm = activeElem.getCTM()
                RAD2DEG = 180 / Math.PI;
                var rotatedDeg = Math.atan2(ctm.b, ctm.a) * RAD2DEG;

                finishedElem.setAttribute("rotateAngle", rotatedDeg)

                finishedElem.setAttribute("class", "textElem")

                mySVG.setAttribute('onclick', "placeDrawText()") //---click to add more icons for this session---
                DrawX.style("display", "none")
            finishedElem.setAttribute("onmouseover", "myZoomLevel("+MapZoom+","+id+")")
            finishedElem.setAttribute("onmouseout", "removeZoomLevel()")
            finishedElem.setAttribute("InitZoom", MapZoom)
            domElemG.appendChild(finishedElem)
          setLatLng(finishedElem) //---helperFuncts.js---
           MyMap.dragging.enable()
           MyMap.scrollWheelZoom.enable();

                cw.finishDrawTextButton.disabled = true
                cw.cancelDrawTextButton.disabled = true
                cw.drawTextBotButton.disabled=true
                coverOff()
                WriteText = "";
                NextLine = false
                TspanCnt = 0

                clearInterval(TextBlinkerInterval)
                DrawText = false

                cw.drawTextWriteTextValue.removeEventListener("keypress", cw.drawTextKeyPress)
                cw.drawTextWriteTextValue.removeEventListener("keyup", cw.drawTextKeyUp)

                domActiveElemG.removeChild(activeElem)
                ActiveElem = null

                activeElem = null

            }
    }
    else
    {
        closeIframe("addElemText")
        closeDrawText()
    }
}

//=====================EDIT==========================================

var EditText = false
var DrawTextEditId
var EditThisText
function editTextDraw(elemObjEdit, evt) //--right button/mousedown on text---
{
    var isRightMB;
    var evtW = window.event;
    if(evtW)
    {
        isRightMB = evtW.which == 3;
        if (!isRightMB) // IE, Opera
            isRightMB = evtW.button == 2;
    }
    else //---firefox--
        isRightMB = evt.which == 3;

    var myZoomLevel=+elemObjEdit.getAttribute("InitZoom")
    if(isRightMB&&DrawText==false&&myZoomLevel==MapZoom)
    {
        EditThisText = elemObjEdit

        DrawTextEditId = elemObjEdit.getAttribute("id")//---used in cancel edit--

        ActiveElem = null
        activeElem = null

        EditText = true
        if(addElemTextLoad==false)
        {
            openIframe("AddElem", "addElemText", 10)
            //startTextDraw()
        }
        else if(addElemTextViz==false)
        {
            openIframe("AddElem", "addElemText", 10)
            setEditText()
        }
        else
            setEditText()
    }

}
//---after iframe loaded see sendSize() at addElemText.htm---
var EditTextObj
function setEditText()
{
    MyMap.dragging.disable()
    MyMap.scrollWheelZoom.disable();

    RotateAngle = 0
    var cw = addElemTextCw
    cw.botTextTable.style.backgroundColor = "orange"
    cw.drawTextTopTable.style.backgroundColor = "orange"
    cw.containerDiv.style.backgroundColor = "orange"
    cw.textClickOnTD.style.visibility="hidden"
    cw.editTextSpan.innerHTML = "Edit This"
    mySVG.removeAttribute('onclick')

    var elemObjEdit = document.getElementById(DrawTextEditId)

    EditTextObj = elemObjEdit.cloneNode(true)
    EditTextObj.setAttribute("id", "activeElem")
    EditTextObj.removeAttribute("onmousedown")
    elemObjEdit.style.visibility = "hidden"
    addNoSelectAtText()
    textFillColor = elemObjEdit.getAttribute("fill")
    textStrokeColor = elemObjEdit.getAttribute("stroke")
    var fontFamily = elemObjEdit.getAttribute("font-family")
    var fontWeight = elemObjEdit.getAttribute("font-weight")
    var fontStyle = elemObjEdit.getAttribute("font-style")
    var fontSize = +elemObjEdit.getAttribute("font-size")
    var shadow = elemObjEdit.getAttribute("filter")
    if(shadow)
        cw.shadowDrawTextCheck.checked=true
    else
        cw.shadowDrawTextCheck.checked=false

    var strokeWidth=fontSize*.02
    //----reset selections---
    for(var k = 0; k<cw.drawTextFontSizeSelect.options.length; k++)
    {
        var size = cw.drawTextFontSizeSelect.options[k].text
        if(size==fontSize)
        {
            cw.drawTextFontSizeSelect.selectedIndex = k
            break
        }
    }

    for(var k = 0; k<cw.drawTextFontFamilySelect.options.length; k++)
    {
        var family = cw.drawTextFontFamilySelect.options[k].text
        if(family==fontFamily)
        {
            cw.drawTextFontFamilySelect.selectedIndex = k
            break
        }
    }
    for(var k = 0; k<cw.drawTextFillSelect.options.length; k++)
    {
        var fill = cw.drawTextFillSelect.options[k].value
        if(fill==textFillColor)
        {
            cw.drawTextFillBg.style.background = textFillColor
            cw.drawTextFillSelect.selectedIndex = k
            break
        }
    }
    for(var k = 0; k<cw.drawTextStrokeSelect.options.length; k++)
    {
        var stroke = cw.drawTextStrokeSelect.options[k].value
        if(stroke==textStrokeColor)
        {
            cw.drawTextStrokeBg.style.background = textStrokeColor
            cw.drawTextStrokeSelect.selectedIndex = k
            break
        }
    }



    if(fontWeight=="bold")
        cw.drawTextBoldCheck.checked = true
        else
            cw.drawTextBoldCheck.checked = false

            if(fontStyle=="italic")
            cw.drawTextItalicCheck.checked = true
            else
                cw.drawTextItalicCheck.checked = false
                cw.fontFamilySpan.style.fontWeight = fontWeight
                cw.fontFamilySpan.style.fontStyle = fontStyle

                ActiveElem = ActiveElemG.append("g")
                .attr("id", "activeElem")
                .attr("fill", textFillColor)
                .attr("stroke", textStrokeColor)
                .attr("stroke-width", strokeWidth)
                .attr("font-size", fontSize)
                .attr("font-family", fontFamily)
                .attr("font-weight", fontWeight)
                .attr("font-style", fontStyle)
                .attr("transform", elemObjEdit.getAttribute("transform"))
                .attr("filter", elemObjEdit.getAttribute("filter"))
                .attr("class", "dragTargetObj")

                activeElem = document.getElementById("activeElem")

                var ctm = elemObjEdit.getCTM()
                RAD2DEG = 180 / Math.PI;
    var rotatedDeg = Math.atan2(ctm.b, ctm.a) * RAD2DEG;

    cw.adjustedRotateTextValue.value = rotatedDeg

    TextElem = ActiveElem.append("svg:text")
    .attr("id", "activeText")
    .attr("x", 0)
    .attr("y", 0)

    ActiveTspan = TextElem.append("tspan")
    .attr("id", "activeTspan")
    .text(elemObjEdit.textContent)

    WriteText = elemObjEdit.textContent
    cw.drawTextWriteTextValue.value = WriteText
    activeTspan = document.getElementById("activeTspan")
    //---blinker---!
    var blink = "|";

    TextBlinker = TextElem.append("tspan")
    .text(blink)
    .style("visibility", "visible")
    .attr("id", "textBlinker")
    .attr("dx", "5")
    .attr("stroke", "none")
    .attr("fill", textFillColor)
    .attr("fill-opacity", 1)
    .attr("font-weight", "normal")
    .attr("font-style", "normal")
    .attr("font-family", "Arial")
    .attr("font-size", elemObjEdit.getAttribute("font-size"))

    startBlinker()
    mySVG.setAttribute("onmousedown", "startDragText(evt)")
    mySVG.setAttribute("onmousemove", "dragText(evt)")
    mySVG.setAttribute("onmouseup", "endDragText(evt);addElemTextCw.focusText()")

    ActiveElem = d3.select("#activeElem")
    activeElem = document.getElementById("activeElem")

    cw.botTextTable.style.backgroundColor = "orange"

    cw.drawTextTopTable.style.backgroundColor = "orange"
    cw.editTextSpan.innerText = "Edit This"
    cw.deleteDrawTextButton.style.visibility = "visible"
    cw.finishDrawTextButton.disabled = false
    cw.cancelDrawTextButton.disabled = false
            cw.drawTextBotButton.disabled=false
               cw.drawTextTopButton.style.visibility = "visible"
        cw.drawTextBotButton.style.visibility = "visible"

    cw.drawTextWriteTextValue.value = ""

    cw.drawTextWriteTextValue.addEventListener("keypress", cw.drawTextKeyPress, false)
    cw.drawTextWriteTextValue.addEventListener("keyup", cw.drawTextKeyUp, false)

    ActiveElem.style("cursor", "move")
    DrawX.attr("stroke", "darkorange")
    DrawX.style("display", "inline")
    DrawX.attr("transform", ActiveElem.attr("transform"))
    coverOn()
    cw.focusText()
}

function finishEditText()
{
    if(WriteText!="")
    {
        if(document.getElementById("activeElem"))
        {
            var cw = addElemTextCw

            EditThisText.setAttribute("onmousedown", "editTextDraw("+DrawTextEditId+",evt)")

            EditThisText.setAttribute("font-size", ActiveElem.attr("font-size"))
            EditThisText.setAttribute("stroke", ActiveElem.attr("stroke"))
            EditThisText.setAttribute("stroke-width", ActiveElem.attr("stroke-width"))
            EditThisText.setAttribute("fill", ActiveElem.attr("fill"))
            EditThisText.setAttribute("font-family", ActiveElem.attr("font-family"))
            EditThisText.setAttribute("font-weight", ActiveElem.attr("font-weight"))
            EditThisText.setAttribute("font-style", ActiveElem.attr("font-style"))
            EditThisText.setAttribute("transform", ActiveElem.attr("transform"))
            EditThisText.setAttribute("filter", ActiveElem.attr("filter"))

            EditThisText.textContent = WriteText
            EditThisText.style.visibility = ""
            EditThisText.style.cursor = "default"
            EditThisText.setAttribute("class", "textElem")

            EditThisText.setAttribute("rotateAngle", RotateAngle)
                setLatLng(EditThisText) //---helperFuncts.js---
            domActiveElemG.removeChild(activeElem)
            ActiveElem = null

            activeElem = null

            DrawX.style("display", "none")

            cw.finishDrawTextButton.disabled = true
            cw.cancelDrawTextButton.disabled = true
            coverOff()
            WriteText = "";
            NextLine = false
            TspanCnt = 0

            clearInterval(TextBlinkerInterval)

            EditThisText.style.display = ""

            if(EditText==true)
            {
                EditText = false
                // updateText()
            }

            closeIframe("addElemText")
            closeDrawText()

        }
    }
    else
    {
        closeIframe("addElemText")
        closeDrawText()
    }

}

var TextDeleted = false
//---button---
function removeCurrentDrawText()
{

    domActiveElemG.removeChild(activeElem)
    var elemObjEdit = document.getElementById(DrawTextEditId)
    domElemG.removeChild(elemObjEdit)
    TextDeleted = true
    EditText = false
    ActiveElem = null

    activeElem = null

    var cw = addElemTextCw

    closeDrawText()
    closeIframe("addElemText");

}

//====================Top/Bot===================
function topDrawText()
{

       finishEditText()
      var elemObjEdit = document.getElementById(DrawTextEditId)



    domElemG.appendChild(elemObjEdit)


}
function botDrawText()
{
    if(EditText)
    {

          finishEditText()
        var elemObjEdit = document.getElementById(DrawTextEditId)
        domElemG.insertBefore(elemObjEdit,domElemG.firstChild)


   }
   else
   {
        finishDrawText()
        domElemG.insertBefore(domElemG.lastChild,domElemG.firstChild)
   }
}




function rotateTextAdjust(factor)
{
    var cw = addElemTextCw
    var mult = parseFloat(cw.rotateDrawTextAdjustSelect.options[cw.rotateDrawTextAdjustSelect.selectedIndex].text)
    var rotateAdd = parseFloat(factor)*mult

    cw.adjustedRotateTextValue.value = rotateAdd+parseFloat(cw.adjustedRotateTextValue.value)

    if(ActiveElem)
    {
        rote("activeElem", rotateAdd)
        rote("domDrawX", rotateAdd)
    }
}
function showDrawTextFillBg()
{
    var cw = addElemTextCw
    var fill = cw.drawTextFillSelect.options[cw.drawTextFillSelect.selectedIndex].value
    if(fill!="none")
        cw.drawTextFillBg.style.backgroundColor = fill
        else
            cw.drawTextFillBg.style.backgroundColor = ""
            if(cw.drawTextFillSelect.selectedIndex==0)
        {
            ActiveElem.attr("fill", "white")
            ActiveElem.attr("fill-opacity", 0)

        }
        else
            if(ActiveElem)
        {
            ActiveElem.attr('fill', fill)
            TextBlinker.attr('fill', fill)
        }

}
function showDrawTextStrokeBg()
{
    var cw = addElemTextCw
    var stroke = cw.drawTextStrokeSelect.options[cw.drawTextStrokeSelect.selectedIndex].value
    if(stroke!="none")
        cw.drawTextStrokeBg.style.backgroundColor = stroke
        else
            cw.drawTextStrokeBg.style.backgroundColor = ""
        if(cw.drawTextStrokeSelect.selectedIndex==0)
        {
            ActiveElem.attr("stroke", "none")
            ActiveElem.attr("stroke-width", 0)

        }
        else
        if(ActiveElem)
        {
            ActiveElem.attr('stroke', stroke)
          var fontSize = +cw.drawTextFontSizeSelect.options[cw.drawTextFontSizeSelect.selectedIndex].text
           ActiveElem.attr('stroke-width', fontSize*.02)


        }

}



function drawTextFillSelected()
{
    var cw = addElemTextCw
    var fill = cw.drawTextFillSelect.options[cw.drawTextFillSelect.selectedIndex].value
    if(cw.drawCircleTextSelect.selectedIndex==0)
    {
        ActiveElem.attr("fill", "white")
        ActiveElem.attr("fill-opacity", 0)

    }
    else
        if(ActiveElem)
    {
        ActiveElem.attr('fill', fill)
        TextBlinker.attr('fill', fill)
    }

}